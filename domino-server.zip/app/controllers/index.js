
module.exports = {
  home: require('./home_controller'),
  user: require('./user_controller'),
};
